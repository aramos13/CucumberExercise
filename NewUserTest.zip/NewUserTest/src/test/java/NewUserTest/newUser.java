package NewUserTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import cucumber.runtime.PendingException;
import cucumber.table.DataTable;

public class newUser {
	WebDriver driver = null;
	
	//Using selenium, go to the following page and register a new user:
	public void goToNewtours() { 
		driver = new FirefoxDriver(); 
		driver.navigate().to("http://newtours.demoaut.com"); 
		driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr/td[2]/a"));
	}
	
	@Given("I am a new user$")
	public void newUserPage() {
		System.out.println("I am a new user");
	}
	//Fill  Register page with Cucumber
	   @When("^I register my data correctly in the page for a new user \"(.*)\"$") 
	   public void register(DataTable table) {
		   List<List<String>> data = table.asList(String.class);
		   System.out.println(data.get(0).get(0) + " | " + data.get(0).get(1));
		   
		   driver.findElement(By.name("firstName")).sendKeys(data.get(1).get(1));
		   driver.findElement(By.name("lastName")).sendKeys(data.get(2).get(1));
		   driver.findElement(By.name("phone")).sendKeys(data.get(3).get(1));
		   driver.findElement(By.name("userName")).sendKeys(data.get(4).get(1));
		   driver.findElement(By.name("address1")).sendKeys(data.get(5).get(1));
		   driver.findElement(By.name("city")).sendKeys(data.get(6).get(1));
		   driver.findElement(By.name("state")).sendKeys(data.get(7).get(1));
		   driver.findElement(By.name("postalCode")).sendKeys(data.get(8).get(1));
		   //driver.findElement(By.name("country")).sendKeys(data.get(9).get(1));
		   driver.findElement(By.name("email")).sendKeys(data.get(10).get(1));
		   driver.findElement(By.name("password")).sendKeys(data.get(11).get(1));
		   driver.findElement(By.name("confirmPassword")).sendKeys(data.get(12).get(1));
		   
		   Select countryDropDown = new Select(driver.findElement(By.name("country")));
		   countryDropDown.selectByValue("132");
		   
		   driver.findElement(By.name("register")).click();
		   throw new PendingException();
	   } 
	   
	   @Then("I should get a welcome message$")
	   public void userRegistrationSuccess() {
		   if(driver.getCurrentUrl().equalsIgnoreCase("http://newtours.demoaut.com/mercuryregister.php?osCsid=7ac8cbda32542966ea13207ca574b7f6")) {
			   System.out.println("Test Failed");
		   }else
			   System.out.println("WELCOME");
	   }
	   
	  

}
