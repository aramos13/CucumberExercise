package TripTest;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.annotation.en.And;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import cucumber.runtime.PendingException;
import cucumber.table.DataTable;

public class tripFlight {
	
	WebDriver driver = null;
	
	//Using selenium, go to the following page and use user:mercury and pw:mercury and book a round trip flight!
	public void goToNewtours() { 
		System.out.println("go to network method");
		driver = new FirefoxDriver(); 
		driver.navigate().to("http://newtours.demoaut.com"); 

		WebElement  element = driver.findElement(By.name("userName"));
		element.sendKeys("mercury");
		
		driver.findElement(By.className("password"));
		element.sendKeys("mercury");
		driver.findElement(By.name("login")).submit();
	}
	
	@Given("I am an user to book a first class roundtrip for passengers on December in Unifer Airlines")
	public void reservation(){
		
		List<WebElement> lstChecks =driver.findElements(By.name("tripType"));
		for (int i=0;i<lstChecks.size();i++){
			if (lstChecks.get(i).getAttribute("value").toString().equals("roundtrip")){

				lstChecks.get(i).click();
				break;
			}
		}
		new Select(driver.findElement(By.name("passCount"))).selectByValue("3");
		new Select(driver.findElement(By.name("fromMonth"))).selectByValue("12");
		new Select(driver.findElement(By.name("fromDay"))).selectByValue("19");
		
	}
	
	@And("departing from Paris")
	public void departing() {
		WebElement dropDownPassengers = driver.findElement(By.name("fromPort"));
		Select oSelectPassengers = new Select(dropDownPassengers);
		oSelectPassengers.selectByValue("Paris");
	
	}
	
	@And("Arriving to Acapulco")
	public void arriving() {
		WebElement dropDownPassengers = driver.findElement(By.name("toPort"));
		Select oSelectPassengers = new Select(dropDownPassengers);
		oSelectPassengers.selectByValue("Acapulco");
		
		WebElement radioButtonFirstClass = driver.findElement(By.cssSelector("Input[value='First']"));
		radioButtonFirstClass.click();
		
		WebElement dropDownAirline = driver.findElement(By.name("airline"));
		Select oSelectAirline = new Select(dropDownAirline);
		oSelectAirline.selectByValue("Unified Airlines");
		
		driver.findElement(By.name("findFlights")).click();
		driver.findElement(By.name("reserveFlights")).click();
	}
	
	@When("I register my data to book a trip correctly in the page$")
	public void registerData(DataTable passengerData) {
		List<Map<String, String>> list = passengerData.asList(String.class);
		for(int i=1; i<list.size(); i++) {
			
			driver.findElement(By.name("passFirst"+i)).sendKeys(passengerData + ""+i);
			
			for (int a=1; a<=i; a++) {
				driver.findElement(By.name("passLast"+i)).sendKeys(list.get(i).get(a));
				
			}
			
			
		}
		
		Select cardTypeDropDown = new Select(driver.findElement(By.name("creditCard")));
		cardTypeDropDown.selectByValue("BA");
		
		WebElement  elementNumber = driver.findElement(By.name("firstname"));
		elementNumber.sendKeys("1234567890127698");
		
		Select expirationMonthDropDown = new Select(driver.findElement(By.name("cc_exp_dt_mn")));
		expirationMonthDropDown.selectByValue("03");
		Select expirationYearDropDown = new Select(driver.findElement(By.name("cc_exp_dt_yr")));
		expirationYearDropDown.selectByValue("2010");
		WebElement  elementFname = driver.findElement(By.name("cc_frst_name"));
		elementFname.sendKeys("Test1");
		WebElement  elementMname = driver.findElement(By.name("cc_mid_name"));
		elementMname.sendKeys("TestMiddelName");
		WebElement  elementLname = driver.findElement(By.name("cc_last_name"));
		elementLname.sendKeys("LastNameTest");
		
		WebElement checkBoxTicketless = driver.findElement(By.name("ticketLess"));
		checkBoxTicketless.click();
			
		driver.findElement(By.name("buyFlights")).click();
	}
	
	@Then("I should get confirmation message for my trip$")
	public void confirmation() {
		System.out.println("FLIGHT CONFIRMATION");
		driver.close();
		
	}

}
